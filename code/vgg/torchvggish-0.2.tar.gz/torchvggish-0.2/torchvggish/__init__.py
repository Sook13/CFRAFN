from .torchvggish import *
from .vggish_input import *
from .vggish_params import *

name = "torchvggish"
